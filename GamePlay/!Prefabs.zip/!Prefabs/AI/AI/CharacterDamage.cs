//CharacterDamage.cs by Azuline Studios© All Rights Reserved
//Applies damage to NPCs 
using UnityEngine;
using System.Collections;
using System.Collections.Generic;



public class CharacterDamage : MonoBehaviour {
	public UnityEngine.Events.UnityEvent onDie; // for save addon by PixelCrushers
	private AIPlayerMotor AIComponent;
	
	public float hitPoints = 100.0f;

	public bool destroyAfterdeath = true;
	

	
	
	
	public AudioClip dieSound;

	public AnimationClip[] possibleDeathAnimation;


	private Transform myTransform;


	protected AnimationClipOverrides clipOverrides;

	protected AnimatorOverrideController animatorOverrideController;

	void OnEnable (){
		myTransform = transform;
		
		
		if(!AIComponent){
			AIComponent = myTransform.GetComponent<AIPlayerMotor>();
		}
		
		
		
	}

    private void Start()
    {
		//SetUpRandomDeathAnimation();
	}

    public void SetUpRandomDeathAnimation()
    {
		AIComponent.AnimatorComponent.applyRootMotion = true;
		animatorOverrideController = new AnimatorOverrideController(AIComponent.AnimatorComponent.runtimeAnimatorController);
		AIComponent.AnimatorComponent.runtimeAnimatorController = animatorOverrideController;
		clipOverrides = new AnimationClipOverrides(animatorOverrideController.overridesCount);
		animatorOverrideController.GetOverrides(clipOverrides);
		clipOverrides["Falling Back Death"] = possibleDeathAnimation[Random.Range(0, possibleDeathAnimation.Length)];
		animatorOverrideController.ApplyOverrides(clipOverrides);
		
	}


	
	//this method called if the NPC dies and only has one capsule collider for collision
	//which will be instantiated in place of the main NPC object (which is removed from the scene)
	public void Die() {

		if (AIComponent == null) return;

		if(destroyAfterdeath)
		SetUpRandomDeathAnimation();
		
	

	
		GetComponent<Collider>().enabled = false;


		AIComponent.StopAllCoroutines();
		AIComponent.AnimatorComponent.SetLayerWeight(1, 1);
		AIComponent.AnimatorComponent.SetBool("Die",true);
		AIComponent.NPCAttackComponent.enabled = false;
		if (AIComponent.agent.isOnNavMesh) { 
		AIComponent.agent.isStopped = true;
		AIComponent.agent.enabled = false;
        }
        AIComponent.enabled = false;
		this.StopAllCoroutines();
		AIComponent.StopCoroutine("InitiateAIBehavior");

		onDie?.Invoke();
		if(destroyAfterdeath)
		Destroy(this.gameObject,4);

	}

    public class AnimationClipOverrides : List<KeyValuePair<AnimationClip, AnimationClip>>
    {
        public AnimationClipOverrides(int capacity) : base(capacity) { }

        public AnimationClip this[string name]
        {
            get { return this.Find(x => x.Key.name.Equals(name)).Value; }
            set
            {
                int index = this.FindIndex(x => x.Key.name.Equals(name));
                if (index != -1)
                    this[index] = new KeyValuePair<AnimationClip, AnimationClip>(this[index].Key, value);
            }
        }
    }
}