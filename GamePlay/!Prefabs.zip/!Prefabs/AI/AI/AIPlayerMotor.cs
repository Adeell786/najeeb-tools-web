//AI.cs by Azuline Studios© All Rights Reserved
//Allows NPC to track and attack targets and patrol waypoints.
using UnityEngine;
using UnityEngine.AI;//
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;

using UnityEngine.Events;
public enum NPCType {MelePunch,AssaultRifle,AssaultPistol,MeleWeapon}
public class AIPlayerMotor : MonoBehaviour {

	public UnityEvent onEnableEvent;
	public UnityEvent onDisableEvent;
	[Header("General Settings")]
	public NPCType npcType;
	public bool attackOnSeeTarget = false;
	public LayerMask searchMask = 0;//only layers to include in target search (for efficiency)
	public GameObject possibleTarget;
	[HideInInspector]
	public Transform playerTransform;
	[HideInInspector]
	public GameObject NPCMgrObj;
	
	[HideInInspector]
	public AIFireBrain NPCAttackComponent;
	[HideInInspector]
	public CharacterDamage CharacterDamageComponent;
	
	[HideInInspector]
	public AIPlayerMotor TargetAIComponent;
	[HideInInspector]
	public NavMeshAgent agent;
	[HideInInspector]
	public Collider[] colliders;
	private bool collisionState;
	[HideInInspector]
	public Animator AnimatorComponent;
	
	
	public Transform objectWithAnims;


	[Header("Movement Settings")]
	public float runSpeed = 6.0f;
	public float walkSpeed = 1.0f;
	
	public float walkAnimSpeed = 1.0f;
	
	public float runAnimSpeed = 1.0f;
	private float speedAmt = 1.0f;
	private float lastRunTime;//to prevent rapid walking, then running when following player
	[HideInInspector]
	public float idleYaw = 0.0f;
	[HideInInspector]
	public float movingYaw = 0.0f;
	private float yawAmt;

	[HideInInspector]
	public int factionNum = 1;//1 = human(friendly to player), 2 = alien(hostile to player), 3 = zombie(hostile to all other factions)
	[HideInInspector]
	public bool ignoreFriendlyFire;
	[HideInInspector]
	
	public bool playerAttacked;//to make friendly NPCs go hostile if attacked by player
	[HideInInspector]
	public float attackedTime;

	//waypoints and patrolling
	[HideInInspector]
	public Transform myTransform;
	private Vector3 upVec;//cache this for optimization;
	public bool huntPlayer;
	
	public bool patrolOnce;
	
	public bool walkOnPatrol = true;
	public  Transform curWayPoint;
	
	public WaypointGroup waypointGroup;
	
	public int firstWaypoint = 1;
	
	public bool standWatch;
	[HideInInspector]
	public bool followPlayer;
	[HideInInspector]

	public bool followOnUse;
	[HideInInspector]
	public bool leadPlayer;
	[HideInInspector]
	public bool orderedMove;
	[HideInInspector]
	public bool playerFollow;//true if this NPC wants player to follow them (wont take move orders from player, only from MoveTrigger.cs)
	private bool animInit;//to bypass normal AI update interval for correct animation initialization
	
	private bool  countBackwards = false;
	[Tooltip("Minimum distance to destination waypoint that NPC will consider their destination as reached.")]
	
	public float pickNextDestDist = 2.5f;
	private Vector3 startPosition;
	private float spawnTime;


	private float stepInterval;
	private float stepTime;
	[Header("Attack Settings")]
	public bool isMele = false;
	//targeting and attacking
	[SerializeField]
	float minShootRange = 4;
	[SerializeField]
	float maxShootRange = 10;
	
	[HideInInspector]
	public float shootRange = 15.0f;
	[Tooltip("Range that NPC will start chasing target until they are within shoot range.")]
	[HideInInspector]
	public float attackRange = 30.0f;
	[Tooltip("Range that NPC will hear player attacks.")]
	[HideInInspector]
	public float listenRange = 30.0f;
	[Tooltip("Time between shots (longer for burst weapons).")]

	[SerializeField]
	float minShootDuration = 1;
	[SerializeField]
	float maxShootDuration = 2;
	public float shotDuration = 0.0f;
	[Tooltip("Speed of attack animation.")]
	public float shootAnimSpeed = 1.0f;
	[HideInInspector]
	public float attackRangeAmt = 30.0f;//increased by character damage script if NPC is damaged by player
	
	 float sneakRangeMod = 0.4f;
	

	public float minShootAngle = 3.0f;
	[SerializeField]
	float minDelayShootTime = 0.2f;
	[SerializeField]
	float maxDelayShootTime = 0.5f;
	
	public float delayShootTime = 0.35f;
	
	public float randShotDelay = 0.75f;
	
	public float eyeHeight = 0.4f;
	
	public bool drawDebugGizmos;
	
	public Transform target = null;
	
	public bool targetVisible;
	private float lastVisibleTime;
	private Vector3 targetPos;
	
	[HideInInspector]
	public float attackTime = -16.0f;//time last attacked
	private bool attackFinished = true;
	private bool turning;//true if turning to face target
	[HideInInspector]
	public bool cancelRotate;
	

	private float targetDistance;
	private Vector3 targetDirection;
	private RaycastHit[] hits;
	public bool sightBlocked;//true if sight to target is blocked
	[HideInInspector]
	public bool playerIsBehind;//true if player is behind NPC
	
	public float targetEyeHeight;
	private bool pursueTarget;
	[HideInInspector]
	public Vector3 lastVisibleTargetPosition;
	[HideInInspector]
	public float timeout = 0.0f;//to allow NPC to resume initial behavior after searching for target
	
	 bool heardPlayer = false;
	
	 bool heardTarget = false;
	[HideInInspector]
	public bool damaged;//true if attacked
	private bool damagedState;
	[HideInInspector]
	public float lastDamageTime;


	
	[HideInInspector]
	public RaycastHit attackHit;

	[HideInInspector]
	public bool spawned = false;

	public AudioClip[] tauntSounds;

	bool initiatedAtFirst = false;
	
	void Start(){




    }
	


	void OnEnable(){

		onEnableEvent?.Invoke();

		this.StopAllCoroutines();

        if (objectWithAnims == null) { objectWithAnims = transform; }
        AnimatorComponent = objectWithAnims.GetComponent<Animator>();//set reference to Mecanim animator component
        Init();

        //set layermask to layers such as layer 10 (world collision) and 19 (interactive objects) for target detection 
        //	searchMask = ~(~(1 << 10) & ~(1 << 0) & ~(1 << 13) & ~(1 << 11) & ~(1 << 20));

        //if there is no objectWithAnims defined, use the Animation Component attached to this game object


        if (possibleTarget)
            playerTransform = possibleTarget.transform;
		//else
			//enabled = false;	

        NPCAttackComponent = GetComponent<AIFireBrain>();
        CharacterDamageComponent = GetComponent<CharacterDamage>();

        //Get all colliders for this NPC's body parts 
        colliders = GetComponentsInChildren<Collider>();

        attackRangeAmt = attackRange;

        AnimatorComponent.SetInteger("AnimState", 0);
        if (possibleTarget)
            target = possibleTarget.transform;

        //StopAllCoroutines();

      //  StartCoroutine(InitiateAIBehavior());

		StartCoroutine("InitiateAIBehavior");

    }

	private void OnDisable()
	{
		onDisableEvent?.Invoke();
		NPCAttackComponent.StopAllCoroutines();
       
            this.target = null;
            this.possibleTarget = null;

            if (agent.isActiveAndEnabled)
                agent.ResetPath();
            StopCoroutine("InitiateAIBehavior");
		targetVisible = false;
		sightBlocked = true;
		attackFinished = true;
		
        

    }

	public void Init()
    {
		shootRange = Random.Range(minShootRange, maxShootRange);
		shotDuration = Random.Range(minShootDuration, maxShootDuration);
		delayShootTime = Random.Range(minDelayShootTime, maxDelayShootTime);
		AnimatorComponent.SetFloat("WalkAnimSpeed", walkAnimSpeed);
		AnimatorComponent.SetFloat("RunAnimSpeed", runAnimSpeed);
		AnimatorComponent.SetFloat("ShootAnimSpeed", shootAnimSpeed);


		myTransform = transform;
		upVec = Vector3.up; ;
		startPosition = myTransform.position;
		timeout = 0.0f;
		attackedTime = -16f;//set to negative value to prevent NPCs from having larger search radius briefly after spawning


		collisionState = false;

	}
	Vector3 direction;
	float distance;
	public bool targetFocused = false;
	void Update()
	{
		if (possibleTarget != null)
			target = possibleTarget.transform;

		if(target)
		distance = Vector3.Distance(myTransform.position, target.position);
		
		if (target && targetVisible && distance < shootRange)
		{
			targetFocused = true;
		    direction = possibleTarget.transform.position - myTransform.position;
			direction.y = 0;
			//Debug.LogError("Now Rotating");

            if (direction.x != 0 && direction.z != 0)
			{
				// Rotate towards the target
		
				myTransform.rotation = Quaternion.Slerp(myTransform.rotation, Quaternion.LookRotation(direction), 20 * Time.deltaTime);
				myTransform.eulerAngles = new Vector3(0, myTransform.eulerAngles.y, 0);
			}
			else
				targetFocused = false;
		}
	}

    //void InitiateSequenceDelayed()
    //   {
    //	StartCoroutine(InitiateAIBehavior());
    //}

    //initialize NPC behavior
    public IEnumerator InitiateAIBehavior(){

	

		//yield return new WaitForSeconds(0.1f);//wait for object to initialize

		//initialize navmesh agent
		agent = GetComponent<NavMeshAgent>();
		agent.enabled = false;//Navmesh agent should also be deactivated on prefab to prevent error when spawning
    	agent.enabled = true;
		agent.speed = runSpeed;
		agent.acceleration = 60.0f;

		if(!agent.isOnNavMesh){
			yield return null;//wait for navmesh agent to find navmesh and initialize
		}

		if(agent.isOnNavMesh){
			spawnTime = Time.time;
			//StartCoroutine(PlayFootSteps());
			if(objectWithAnims != myTransform){
				//StartCoroutine(UpdateModelYaw());
			}
			if(!huntPlayer){
				//determine if NPC should patrol or stand watch
				if(!standWatch && waypointGroup && waypointGroup.wayPoints[firstWaypoint - 1]){
					curWayPoint = waypointGroup.wayPoints[firstWaypoint - 1];
					speedAmt = runSpeed;
					startPosition = curWayPoint.position;
					TravelToPoint(curWayPoint.position);
					StartCoroutine(Patrol());
				}else{
					TravelToPoint(startPosition);
					StartCoroutine(StandWatch());
				}
			}else{
				//hunt the player accross the map
				factionNum = 2;
				target = playerTransform;
				//targetEyeHeight = FPSWalker.capsule.height * 0.25f;
				lastVisibleTargetPosition = target.position + (target.up * targetEyeHeight);
				attackRange = 2048.0f;
				
				StartCoroutine(AttackTarget());

				speedAmt = runSpeed;
				

				//TravelToPoint(possibleTarget.transform.position);
			}
		}else{
			Debug.Log("No Navmesh found");
		}
	}

	

	//draw debug spheres in editor
	void OnDrawGizmos() {
        if (drawDebugGizmos)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawSphere(transform.position, 0.2f);
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(transform.position + new Vector3(0.0f, eyeHeight, 0.0f), 0.2f);

            Vector3 myPos = transform.position + (transform.up * eyeHeight);
            Vector3 targetPos = lastVisibleTargetPosition;
            Vector3 testdir1 = (targetPos - myPos).normalized;
            float distance = Vector3.Distance(myPos, targetPos);
            Vector3 testpos3 = myPos + (testdir1 * distance);

            if (Physics.Linecast(myPos, targetPos))
            {
                Gizmos.color = Color.red;
            }
            else
            {
                Gizmos.color = Color.green;
            }

            Gizmos.DrawLine(myPos, testpos3);
            Gizmos.DrawSphere(testpos3, 0.2f);


            if (target)
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawLine(myPos, target.position + (transform.up * targetEyeHeight));
            }

            Gizmos.color = Color.green;
            Gizmos.DrawSphere(transform.position + (transform.forward * 0.6f) + (transform.up * eyeHeight), 0.2f);

            //			Vector3 dirPerpGizmo = Vector3.Cross (transform.forward, Vector3.forward);
            //			dirPerpGizmo.Normalize();
            Vector3 dirPerpGizmo = transform.forward;
            dirPerpGizmo = Quaternion.Euler(0, -90, 0) * dirPerpGizmo;
            agent = GetComponent<NavMeshAgent>();
            Gizmos.color = Color.blue;
            Gizmos.DrawSphere(transform.position + (transform.up * eyeHeight) + (dirPerpGizmo * agent.radius), 0.2f);
            Gizmos.DrawSphere(transform.position + (transform.up * eyeHeight) - (dirPerpGizmo * agent.radius), 0.2f);


        }

    }

    //For when an NPC starts moving from a stationary/idle stance. 
    //This function bypasses normal AI Logic interval of 300ms (for efficiency) and runs the next AI logic pass immediately in the next frame.
    //Doing this prevents NPCs from sliding on the ground when first encountering target or player (prevents delay in movement anim init).
    private void InitializeAnim(){
        if (!animInit && !animInitialized)
        {
            animInit = true;
            animInitialized = true;//to only initialize anims once
        }
        else
        {
            animInit = false;
        }
    }
	
	IEnumerator StandWatch(){
		while (true) {

			if(huntPlayer){
				StartCoroutine(InitiateAIBehavior());
				yield break;
			}
			
			//expand search radius if attacked
			if(attackedTime + 6.0f > Time.time){
				attackRangeAmt = attackRange * 6.0f;//expand enemy search radius if attacked to defend against sniping
			}else{
				attackRangeAmt = attackRange;
			}

			//allow player to push friendly NPCs out of their way
			if(possibleTarget.activeInHierarchy && !collisionState){
				//foreach(Collider col in colliders){
				//	Physics.IgnoreCollision(col, FPSWalker.capsule, true);
				//}
				collisionState = true;
			}

			CanSeeTarget();
			if ((target && targetVisible) || heardPlayer || heardTarget){
				//Debug.LogError("attaching during patrol");
				huntPlayer = true;	
				//yield return StartCoroutine(AttackTarget());
			}
			//else{
			//	if(NPCRegistryComponent){
			//		NPCRegistryComponent.FindClosestTarget(myTransform.gameObject, this, myTransform.position, attackRangeAmt, factionNum);
			//	}
			//}
			if(attackTime < Time.time){
				if((!followPlayer || orderedMove) && Vector3.Distance(startPosition, myTransform.position) > pickNextDestDist){
					if(!orderedMove){
						speedAmt = walkSpeed;//walk to next patrol point, designated position, or starting point
					}else{
						speedAmt = runSpeed;//run to position designated by player
					}
					InitializeAnim();
					TravelToPoint(startPosition);//
				}else if(followPlayer && !orderedMove && Vector3.Distance(possibleTarget.transform.position, myTransform.position) > pickNextDestDist){
					if(followPlayer && Vector3.Distance(possibleTarget.transform.position, myTransform.position) > pickNextDestDist * 2f){
							speedAmt = runSpeed;//run to player if NPC is following and player is far away
							lastRunTime = Time.time;
					}else{
						if(lastRunTime + 2.0f < Time.time){
							speedAmt = walkSpeed;//walk to player if within walking distance
						}
					}
					InitializeAnim();
					TravelToPoint(possibleTarget.transform.position);
				}else{
					//play idle animation
					speedAmt = 0.0f;
					agent.isStopped = true;
					SetSpeed(speedAmt);

					if(attackFinished && attackTime < Time.time){
						AnimatorComponent.SetInteger("AnimState", 0);
					}
					
				}
			}
			if(animInit){
				//only wait one frame till next pass so animations will be initialized now, instead of in 0.3 second normal AI calculation delay
				yield return null;
			}else{
				yield return new WaitForSeconds(0.1f);//wait 0.3 seconds (not every frame) untill next AI calculation (for efficiency)
			}
		}
		
	}
	
	IEnumerator Patrol(){
		while (true) {

			if(huntPlayer){
				StartCoroutine(InitiateAIBehavior());
				yield break;
			}
			
			if(curWayPoint && waypointGroup){//patrol if NPC has a current waypoint, otherwise stand watch
				Vector3 waypointPosition = curWayPoint.position;
				float waypointDist = Vector3.Distance(waypointPosition, myTransform.position);
				int waypointNumber = waypointGroup.wayPoints.IndexOf(curWayPoint);

				//if NPC is close to a waypoint, pick the next one
				if((patrolOnce && waypointNumber == waypointGroup.wayPoints.Count - 1)){
					if(waypointDist < pickNextDestDist){
						speedAmt = 0.0f;
						startPosition = waypointPosition;
                        Debug.LogError("Patroling Stoppped on Patrol Once");
                        StartCoroutine(StandWatch());
						yield break;//cancel patrol if patrolOnce var is true
					}
				}else{	
					if(waypointDist < pickNextDestDist){
						if(waypointGroup.wayPoints.Count == 1){
							speedAmt = 0.0f;
							startPosition = waypointPosition;
							StartCoroutine(StandWatch());
                            Debug.LogError("Patroling Stoppped");
                            yield break;//cancel patrol if NPC has reached their only waypoint
						}
						curWayPoint = PickNextWaypoint (curWayPoint, waypointNumber);
						if(spawned && Vector3.Distance(waypointPosition, myTransform.position) < pickNextDestDist){
							walkOnPatrol = true;//make spawned NPCs run to their first waypoint, but walk on the patrol
						}
					}
				}

				//expand search radius if attacked
				if(attackedTime + 6.0f > Time.time){
					attackRangeAmt = attackRange * 6.0f;//expand enemy search radius if attacked to defend against sniping
				}else{
					attackRangeAmt = attackRange;
				}
				

				//allow player to push friendly NPCs out of their way
				if(possibleTarget)
				if(possibleTarget.activeInHierarchy && !collisionState){
					//foreach(Collider col in colliders){
					//	Physics.IgnoreCollision(col, FPSWalker.capsule, true);
					//}
					collisionState = true;
				}

				//determine if player is within sight of NPC
				CanSeeTarget();
				//if((target && targetVisible) || heardPlayer || heardTarget){

                    if ((target && targetVisible && !sightBlocked && attackOnSeeTarget)){
					Debug.LogError("Attacking during patrol");
					huntPlayer = true;
					//yield return StartCoroutine(AttackTarget());
				}else{

					// Move towards our target
					if(attackTime < Time.time){
						if(orderedMove && !followPlayer){
							if(Vector3.Distance(startPosition, myTransform.position) > pickNextDestDist){
								speedAmt = runSpeed;
								TravelToPoint(startPosition);
							}else{
								//play idle animation
								speedAmt = 0.0f;
								agent.isStopped = true;
								SetSpeed(speedAmt);

								if(attackFinished && attackTime < Time.time){
									AnimatorComponent.SetInteger("AnimState", 0);
								}
								
								StartCoroutine(StandWatch());//npc reached player-designated position, stop patrolling and wait here
								yield break;
							}
						}else if(!orderedMove && followPlayer){
							if(Vector3.Distance(possibleTarget.transform.position, myTransform.position) > pickNextDestDist){
								if(Vector3.Distance(possibleTarget.transform.position, myTransform.position) > pickNextDestDist * 2f){
									speedAmt = runSpeed;
									lastRunTime = Time.time;
								}else{
									if(lastRunTime + 2.0f < Time.time){
										speedAmt = walkSpeed;
									}
								}
								TravelToPoint(possibleTarget.transform.position);
							}else{
								//play idle animation
								speedAmt = 0.0f;
								agent.isStopped = true;
								SetSpeed(speedAmt);

								if(attackFinished && attackTime < Time.time){
									AnimatorComponent.SetInteger("AnimState", 0);
								}
								
							}
						}else{
							//determine if NPC should walk or run on patrol
							if(walkOnPatrol){speedAmt = walkSpeed;}else{speedAmt = runSpeed;}
							TravelToPoint(waypointPosition);
						}
					}
				}
			}else{
				StartCoroutine(StandWatch());//don't patrol if we have no waypoints
				yield break;
			}
			yield return new WaitForSeconds(0.3f);
		}

	}


	void CanSeeTarget(){
	
		//if(spawnTime + 1f > Time.time){//add small delay before checking target visibility
		//	return;
		//}
		
		//stop tracking target if it is deactivated
		if((TargetAIComponent && !TargetAIComponent.enabled) || (target && !target.gameObject.activeInHierarchy)){
			target = null;
			TargetAIComponent = null;
			targetVisible = false;
			heardTarget = false;
			Debug.Log("Tracking Disabled");
			return;
		}

		//target player
		if((factionNum != 1 || playerAttacked) ){

			float playerDistance = Vector3.Distance(myTransform.position + (upVec * eyeHeight), playerTransform.position + (upVec ));

			//listen for player attacks
			if(!heardPlayer && !huntPlayer /*&& FPSWalker.dropTime + 2.5f < Time.time*/){
				if(playerDistance < listenRange && (target == playerTransform  || target == null)){
		

					timeout = Time.time + 6.0f;
					heardPlayer = true;
				}
			}

			if(huntPlayer){
			//	targetEyeHeight = FPSWalker.capsule.height * 0.25f;
				target = playerTransform;
			}

			if(playerDistance < attackRangeAmt){

     

            }

		}

		//calculate range and LOS to target
		if(target == playerTransform ||  (TargetAIComponent && TargetAIComponent.enabled && target != null)){
			Vector3 myPos = myTransform.position + (upVec * eyeHeight);
			targetPos = target.position + (target.up * targetEyeHeight);

			targetDistance = Vector3.Distance(myPos, targetPos);
			targetDirection = (targetPos - myPos).normalized;

			Vector3 targetDirPerp = Vector3.Cross (targetDirection, Vector3.forward);
			targetDirPerp.Normalize();

			if(targetDistance > attackRangeAmt){
				sightBlocked = true;
				targetVisible = false;
				return;//don't continue to check LOS if target is not within attack range
			}

			//check LOS with raycast
			hits = Physics.RaycastAll (myPos, targetDirection, targetDistance, searchMask);

			//sightBlocked = false;

			//detect if target is behind NPC
			//if(!huntPlayer 
			//&& timeout < Time.time
			//&& attackedTime + 6.0f < Time.time
			//&& ((target == playerTransform ) && !heardPlayer)
			//){
			//	Vector3 toTarget = (targetPos - myPos).normalized;
			//	if(Vector3.Dot(toTarget, transform.forward) < -0.45f){
			//		sightBlocked = true;
			//		playerIsBehind = true;
			//		targetVisible = false;
			//		return;
			//	}
			//}
			
			//playerIsBehind = false;

			////check if NPC can see their target
			//for (int i = 0; i < hits.Length; i++)
			//{
			//    if ((!hits[i].transform.IsChildOf(target) && !hits[i].transform.IsChildOf(myTransform))//hit is not NPC's own colliders
			//    || (!playerAttacked//attack player if they attacked us (friendly fire)
			//        && (factionNum == 1 && target != possibleTarget))
			//    )
			//    {
			//        sightBlocked = true;
			//        break;
			//    }
			//    if (hits[i].transform.IsChildOf(target))
			//    {
			//        attackHit = hits[i];
			//        break;
			//    }
			//}
			RaycastHit hit;
			if (Physics.Raycast(transform.position+ Vector3.up*2, transform.forward, out hit, targetDistance))
            {
				Debug.Log("Blocked  "+ hit.collider.gameObject.name);
				if (hit.collider.gameObject != possibleTarget && !hit.collider.transform.IsChildOf(possibleTarget.transform)) { 
					sightBlocked = true;

                }
                else
                {
					sightBlocked = false;
				}
			}
            else
            {
				sightBlocked = false;
            }
			//	if (hit.collider.gameObject != possibleTarget)
			//		sightBlocked = true;

			if (!sightBlocked){
		
					pursueTarget = true;//true when NPC has seen only the player leaning around a corner
					targetVisible = true;
					return;
				
			}else{
				if(TargetAIComponent && !huntPlayer){
					if(TargetAIComponent.attackTime > Time.time && Vector3.Distance(myTransform.position, target.position) < listenRange ){
						timeout = Time.time + 6.0f;
						heardTarget = true;
					}
				}
				targetVisible = false;
				return;
			}
			
		}else{
			targetVisible = false;
			return;
		}
	
	}
	
	IEnumerator Shoot(){

		attackFinished = false;

		//don't move during attack
		speedAmt = 0.0f;
		SetSpeed(speedAmt);
		agent.isStopped = true;


		// Start shoot animation
		AnimatorComponent.SetInteger("AnimState", 3);
		AnimatorComponent.SetTrigger("Attack");


		// Wait until delayShootTime to allow part of the animation to play
		yield return new WaitForSeconds(delayShootTime);
		//attack
		NPCAttackComponent.Fire();

		//if(Random.value <= 0.5)
		//{
		//	if(MAudioManager.Instance)
		//	MAudioManager.Instance.PlayAudioClip(tauntSounds[Random.Range(0, tauntSounds.Length)], transform.position);
		//}

		//if(cancelAttackTaunt){
		//	vocalFx.Stop();
		//}
		attackTime = Time.time + 2.0f;
		// Wait for the rest of the animation to finish
		yield return new WaitForSeconds(delayShootTime + Random.Range(shotDuration, shotDuration + 0.75f));

		attackFinished = true;

		AnimatorComponent.SetInteger("AnimState", 0);
		

	}

	public bool isInShootRange = false;
	public bool hasMinShootAngle = false;
    private bool animInitialized;

    IEnumerator AttackTarget(){

        #if (UNITY_EDITOR)
        // your code here
       // Debug.LogError("Attacking");
        #endif


        while (true) {

			if (Time.timeSinceLevelLoad < 1f)
			{//add small delay before checking target visibility
				yield return new WaitForSeconds(0.3f);
			}



			// no target - stop hunting
			if (target == null || (TargetAIComponent && !TargetAIComponent.enabled) && !huntPlayer){
				timeout = 0.0f;
				heardPlayer = false;
				heardTarget = false;
				damaged = false;
				TargetAIComponent = null;

				Debug.Log("Breaking");
				yield break;
			}
			
			
			float distance = Vector3.Distance(myTransform.position, target.position);
			
			if(!huntPlayer){
				
				//search for player if their attacks have been heard
				if(heardPlayer && (target == playerTransform )){
					InitializeAnim();
					speedAmt = runSpeed;
					SearchTarget(lastVisibleTargetPosition);
				}
				//search for target if their attacks have been heard
				if(heardTarget){
					InitializeAnim();
					speedAmt = runSpeed;
					SearchTarget(lastVisibleTargetPosition);
				}
		
				// Target is too far away - give up	
				if(distance > attackRangeAmt){
					speedAmt = walkSpeed;
					target = null;
					yield break;
				}
				
			}else{
				InitializeAnim();
				target = playerTransform;
				speedAmt = runSpeed;

				
				if(distance > shootRange)
				TravelToPoint(target.position);
			}

			if(pursueTarget){//should NPC attack player collider or leaning collider?
				lastVisibleTargetPosition = possibleTarget.transform.position;
			}else{
				lastVisibleTargetPosition = target.position + (target.up * targetEyeHeight);
			}

			CanSeeTarget();
			if(targetVisible){
				timeout = Time.time + 0f;
			
				if(distance > shootRange){
					if(!huntPlayer){
						SearchTarget(lastVisibleTargetPosition);
					}
				}else{//close to target, rotate NPC to face it
					if(!turning){
						//Debug.Log("Now Turning");
						StopCoroutine("RotateTowards");
						//StartCoroutine(RotateTowards(lastVisibleTargetPosition, 20f, 2f));
					}
					speedAmt = 0.0f;
					SetSpeed(speedAmt);
					agent.speed = speedAmt;
				}

				//InitializeAnim();
				speedAmt = runSpeed;

				Vector3 forward = myTransform.TransformDirection(Vector3.forward);
				Vector3 targetDirection = lastVisibleTargetPosition - (myTransform.position + (myTransform.up * eyeHeight));
				targetDirection.y = 0;
				
				float angle = Vector3.Angle(targetDirection, forward);

				isInShootRange = distance < shootRange;
				hasMinShootAngle = angle < minShootAngle;
				// Start shooting if close and player is in sight
				if (isInShootRange  && hasMinShootAngle)
				{
					if(attackFinished){
						yield return StartCoroutine(Shoot());
					}else{
						speedAmt = 0.0f;
						SetSpeed(speedAmt);
						agent.isStopped = true;
					}
				}
				
			}else{
				if(!huntPlayer){
					if(attackFinished || huntPlayer){
						if(timeout > Time.time){
							InitializeAnim();
							speedAmt = runSpeed;
							SetSpeed(speedAmt);
							SearchTarget(lastVisibleTargetPosition);
						}else{//if timeout has elapsed and target is not visible, resume initial behavior
							heardPlayer = false;
							heardTarget = false;
							speedAmt = 0.0f;
							SetSpeed(speedAmt);
							agent.isStopped = true;
							target = null;
							yield break;
						}
					}
				}
			}
			
			if(animInit){
				//only wait one frame till next pass so animations will be initialized now, instead of in 0.3 second normal AI calculation delay
				yield return null;
			}else{
                yield return new WaitForSeconds(0.6f);//wait 0.3 seconds (not every frame) untill next AI calculation (for efficiency)
               // yield return null;
            }

		}
	}

	//look for target at a location
	void SearchTarget( Vector3 position  ){
		if(attackFinished){
			if(target == playerTransform ||  (TargetAIComponent && TargetAIComponent.enabled)){
				if(!huntPlayer){
					speedAmt = runSpeed;
					TravelToPoint(target.position);
				}
			}else{
				timeout = 0.0f;
				damaged = false;
			}
		}
	}

	//rotate to face target
	public IEnumerator RotateTowards( Vector3 position, float rotationSpeed, float turnTimer, bool attacking = true ){
		float turnTime;
		turnTime = Time.time;

		SetSpeed(0.0f);
		agent.isStopped = true;

		while(turnTime + turnTimer > Time.time && !cancelRotate){
			turning = true;

			if(pursueTarget){
				position = possibleTarget.transform.position;
			}else{
				if((target && attacking && (target == playerTransform || (TargetAIComponent && TargetAIComponent.enabled)))){
					lastVisibleTargetPosition = target.position + (target.up * targetEyeHeight);
				}else{
					lastVisibleTargetPosition = position;
				}
			}
			
			Vector3 direction = lastVisibleTargetPosition - myTransform.position;
			direction.y = 0;
			if(direction.x != 0 && direction.z != 0){
				// Rotate towards the target
				myTransform.rotation = Quaternion.Slerp (myTransform.rotation, Quaternion.LookRotation(direction), rotationSpeed * Time.deltaTime);
				myTransform.eulerAngles = new Vector3(0, myTransform.eulerAngles.y, 0);
				yield return null;
			}else{
				break;//stop rotating 
			}
		}
		cancelRotate = false;
		turning = false;
	}
	
	//Allow tweaking of model yaw/facing direction from the inspector for NPC alignment with attack direction 
	private IEnumerator UpdateModelYaw(){
		while(true){
			
			if(stepInterval > 0.0f){
				yawAmt = Mathf.MoveTowards(yawAmt, movingYaw, Time.deltaTime * 180.0f);
			}else{
				yawAmt = Mathf.MoveTowards(yawAmt, idleYaw, Time.deltaTime * 180.0f);
			}

			objectWithAnims.transform.localRotation = Quaternion.Euler(0.0f, yawAmt, 0.0f);

			yield return null;
		}
	}

	//set navmesh destination and set NPC speed
	void TravelToPoint( Vector3 position  ){
		if(attackFinished){
			if (agent.isOnNavMesh) { 
			agent.SetDestination(position);
			agent.isStopped = false;
			agent.speed = speedAmt;
            }
            SetSpeed(speedAmt);
			
		}
	}
	
	//pick the next waypoint and determine if patrol should continue forward or backward through waypoint group
	Transform PickNextWaypoint( Transform currentWaypoint, int curWaypointNumber  ){
		
		Transform waypoint = currentWaypoint;

		if(!countBackwards){
			if(curWaypointNumber < waypointGroup.wayPoints.Count -1){
				waypoint = waypointGroup.wayPoints[curWaypointNumber + 1];
			}else{
				waypoint = waypointGroup.wayPoints[curWaypointNumber - 1];
				countBackwards = true;
			}
		}else{
			if(curWaypointNumber != 0){
				waypoint = waypointGroup.wayPoints[curWaypointNumber - 1];
			}else{
				waypoint = waypointGroup.wayPoints[curWaypointNumber + 1];
				countBackwards = false;
			}
		}
		return waypoint;
	}

	//play animations for NPC moving state/speed and set footstep sound intervals
	void SetSpeed( float speed  ){

		if( huntPlayer && speed >0)
        {
			AnimatorComponent.SetInteger("AnimState", 2);
		}
        else { 

		if (speed > walkSpeed && agent.hasPath){
			AnimatorComponent.SetInteger("AnimState", 2);
			//stepInterval = runStepTime;
		}else{
			if(speed > 0.0f && agent.hasPath){
				AnimatorComponent.SetInteger("AnimState", 1);
				//stepInterval = walkStepTime;
			}else{
				if(attackFinished && attackTime < Time.time){
					AnimatorComponent.SetInteger("AnimState", 0);
				}
				stepInterval = -1.0f;
			}
		}
		}
	}

	
	//Move an NPC to a specific position 
	public void GoToPosition (Vector3 position, bool runToPos) {
		if(runToPos){
			orderedMove = true;
		}else{
			orderedMove = false;
		}
		cancelRotate = true;
		startPosition = position;
	}

//	//used to change the faction of the NPC
	public void ChangeFaction(int factionChange){
		target = null;
		factionNum = factionChange;
	}

}