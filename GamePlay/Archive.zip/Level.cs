﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
[System.Serializable]
public class EnemyProperties
{

    public float MinHealth, MaxHealth, MinDamagetoplayer, MaxDamagetoplayer;
    public int MinShootrange, MaxShootrange;
 //   [Tooltip("Rate of fire in shots per second.")]
    //[Range(0, 1000)]
    //public float EnemyAiGunrate;
    //public AIStartMode EnemyStertMode;

}
[System.Serializable]
public class PVPSpawningPoint
{
    public GameObject[] PlayerSpawPoint, PlayerAiSpwanPoint, EnemyAiSpawnPoint;




}
public class Level : MonoBehaviour {
	public bool isTimedMission;
	public bool isSurvivalMission;
    public float MissionTime=400f;
	public GameObject StoryCamera;
	public GameObject[] startposition;
	public float enemyDamageamount;
	public string missionStatement;
	public float maxHealth;
	public int RegisterEnemyToKill;
	public int Activatedenemy;
	public int EnemyListenRange;
	public int TotalTimeBomb;
    public Transform playerSpwanPoint;
    [Header("PVP Mode Data")]
    public PVPSpawningPoint PvpSpawningPoint;
    //public float PvpArea = 30f;
    public int MaxTeamMember = 3;
    public int MaxKillInMatch;

    public EnemyProperties enemyProperties;
    void OnEnable(){
       
		float value = LevelsManager.instance.Levels[MConstants.CurrentLevelNumber - 1].maxHealth;
        if (MConstants.CurrentGameMode != MConstants.GAME_MODES.PVP_MODE)
        {
            FindObjectOfType<FPSPlayer>().GetComponent<FPSPlayer>().maximumHitPoints = value;
            FindObjectOfType<FPSPlayer>().GetComponent<FPSPlayer>().hitPoints = value;
            LevelsManager.instance.Healthbar.maxValue = value;
        }
        else
        {
            HudMenuManager.instance.player.maximumHitPoints = 100f;
            HudMenuManager.instance.player.hitPoints = 100f;
            LevelsManager.instance.Healthbar.maxValue = 100;
        }
	}
	public void ActiveCamera(int index){

	}

	public void DeActiveCameras(){

	}

	void activeCars(){

	}

	public void setTimesList(){

	}

	public void EnemyDamages(GameObject Enemy)
	{
		Enemy.gameObject.GetComponent<CharacterDamage>().hitPoints = enemyDamageamount;
	}
}
