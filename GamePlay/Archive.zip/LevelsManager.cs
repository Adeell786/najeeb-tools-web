﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using ControlFreak2;
using UnityEngine.UI;

public class LevelsManager : MonoBehaviour {
	public static LevelsManager instance;
	public Level []Levels;
    public int EnemyListenRange;
    public Slider Healthbar;
    [HideInInspector]
	public float startTime = 0f;
	[HideInInspector]
	public float endTime = 0f;
	public GameObject freeModeLevel;
	public GameObject spawnPoint;
	public Transform []survivalModeSpwanPoints;
	[HideInInspector]
	public Material greenCheckPointMaterial;
    public AI[] enemy;
    [Header("Main PlayerData")]
    public Level PvpMode;
    public GameObject[] AiEnemy;
    public GameObject[] AiPlayer;
    //public GameObject []enemiesList;
    [HideInInspector]
	public Transform player;
	public GameObject []enemiesList;
	public Level survivalLevel;
    public TouchJoystick touchjoyStick;
    int pickpoint;
    public GameObject HealthItem;
	void Awake (){
      
		instance = this;
        if (touchjoyStick == null)
        {
            touchjoyStick = GameObject.FindObjectOfType(typeof(TouchJoystick)) as TouchJoystick;
        }
        if (MConstants.CurrentGameMode==MConstants.GAME_MODES.ENDLESS_MODE)
        {
            freeModeLevel.SetActive(true);
        }
        else if (MConstants.CurrentGameMode == MConstants.GAME_MODES.PVP_MODE)
        {
            PvpMode.gameObject.SetActive(true);
        }
        else
        {
            Levels[MConstants.CurrentLevelNumber - 1].gameObject.SetActive(true);
            if (MConstants.CurrentLevelNumber >= 3)
            {
                touchjoyStick.fadeOutWhenReleased = true;
            }
        }
     
       
    }

    void Start(){

		SetStartTime ();
        if (MConstants.CurrentGameMode != MConstants.GAME_MODES.ENDLESS_MODE && MConstants.CurrentGameMode != MConstants.GAME_MODES.PVP_MODE)
        {
            Invoke("PickupItem", 3f);
        }
       
    }
   
    public void PickupItem()
    {
        enemy = FindObjectsOfType<AI>();
        //for (int i = 0; i < enemy.Length; i++)
        //{
        //    enemy[i].gameObject.GetComponent<CharacterDamage>().gunItem = null;
        //    enemy[i].GetComponent<CharacterDamage>().gunItem = HealthItem;
        //}
        if (enemy.Length!=0)
        {
            pickpoint = Random.Range(0, enemy.Length);
            if (HealthItem != null && enemy[pickpoint].GetComponent<CharacterDamage>())
            {
                enemy[pickpoint].GetComponent<CharacterDamage>().gunItem = HealthItem;
                // enemy[pickpoint].GetComponent<CharacterDamage>().gunObj = null;
                Debug.Log("Assign Randam Dropable Health Item");
            }
        }
       
    }

	public void startGame(){
		if (Levels [MConstants.CurrentLevelNumber - 1].StoryCamera) {
			Levels [MConstants.CurrentLevelNumber - 1].StoryCamera.SetActive (false);
		} 
	}
	public void SetStartTime(){
		startTime = Time.time;
	}

	public void SetEndTime(){
		endTime = Time.time;

	}

	public void SpanEnemy(){
		Transform bestTarget = GetClosestEnemy(survivalModeSpwanPoints);

		if(bestTarget){
			GameObject.Instantiate(enemiesList[Random.Range(0,enemiesList.Length)], bestTarget.position + (Vector3.up), bestTarget.rotation);
		}

	}
	Transform GetClosestEnemy (Transform[] enemies)
	{
		Transform bestTarget = null;
		return bestTarget;
	}

}
