using System.Collections;
using UnityEngine;
using UnityEngine.AI;
public class AISpawnManager : MonoBehaviour
{
    public GameObject aiPrefab; // Drag your AI prefab here
    public Transform spawnPoint; // Set the spawn point in the Unity Editor
    public int maxSpawnLimit = 5;
    public float respawnDelay = 3f;
   // public GameObject enemyPrefab;
    public float spawnDistance = 10f;

    public int currentSpawnCount=0;
    public static AISpawnManager Instance;

    public float spherecastradias;
    public bool staticPossion;
    public Transform Player;
    private void SpawnEnemy1()
    {
       // RaycastHit hitdata;
        NavMeshHit navMeshHit;
        Vector3 SpawnPosition = Player.forward * spawnDistance + Player.position;
        Vector3 randomPoint = SpawnPosition + new Vector3(Random.Range(-3f, 3f), 0, Random.Range(-5, 5));
        // Physics.SphereCast(randomPoint + (Vector3.up * 500f), spherecastradias, Vector3.down, out hitdata, 600f);
        // Project the random point onto the navigation mesh
        if (NavMesh.SamplePosition(randomPoint, out navMeshHit, 5, NavMesh.AllAreas))
        {
            Instantiate(aiPrefab, navMeshHit.position, Quaternion.identity);
        }
        else

        {
            Debug.LogWarning("Cannot spawn enemy outside NavMesh!");
            // If the position is not on the NavMesh, find the nearest point
            //NavMesh.FindClosestEdge(hitdata.point, out navMeshHit, NavMesh.AllAreas);

            //  return navMeshHit.position;
        }

    }
    void Start()
    {
        Instance = this;
        RespawnAI();


    }

    void SpawnAI()
    {
        if (currentSpawnCount < maxSpawnLimit)
        {
            if (!staticPossion)
            {
                SpawnEnemy1();
            }
            else
            {
                Instantiate(aiPrefab, spawnPoint.position, spawnPoint.rotation);
            }
            RespawnAI();
            currentSpawnCount++;
        }
    }

    public void RespawnAI()
    {
        StartCoroutine(RespawnDelay());
    }

    IEnumerator RespawnDelay()
    {
        yield return new WaitForSeconds(respawnDelay);
        SpawnAI();
    }

    public void OnAIDeath()
    {
        currentSpawnCount--;

        if (currentSpawnCount < 0)
            currentSpawnCount = 0;

        SpawnAI();
        Debug.LogError("death");
    }
}
