using UnityEngine;
using UnityEngine.AI;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;
    public float spawnDistance = 10f;
 //   public Camera mainCamera;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))  // You can replace this condition with your own trigger condition
        {
            SpawnEnemy1();
        }
    }

    void SpawnEnemy()
    {
        // Get player position
        Vector3 playerPosition = transform.position;

        // Calculate random spawn position in front of the player
        Vector3 spawnDirection = transform.forward * spawnDistance;
       // Vector3 randomOffset = new Vector3(Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)).normalized * spawnDistance;
        Vector3 spawnPosition = playerPosition + spawnDirection ;

        // Check if the spawn position is on the NavMesh
        NavMeshHit hit;
        if (NavMesh.SamplePosition(spawnPosition, out hit, 5f, NavMesh.AllAreas))
        {
            spawnPosition = hit.position;

            // Spawn the enemy at the calculated position
            Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
        }
        else
        {
            Debug.LogWarning("Cannot spawn enemy outside NavMesh!");
        }
    }
    //void SpawnEnemy1()
    //{
    //    // Set the spawn distance from the player
    //  //  float spawnDistance = 10f;

    //    // Get a random position within camera view
    //    Vector3 randomSpawnPoint = GetRandomPointInCameraView();

    //    // Find the nearest point on the NavMesh
    //    NavMeshHit hit;
    //    if (NavMesh.SamplePosition(randomSpawnPoint, out hit, 10f, NavMesh.AllAreas))
    //    {
    //        // Spawn the enemy at the calculated position
    //        Instantiate(enemyPrefab, hit.position, Quaternion.identity);
    //    }else

    //    {
    //        // If the position is not on the NavMesh, find the nearest point
    //        NavMesh.FindClosestEdge(randomSpawnPoint, out hit, NavMesh.AllAreas);
    //        Instantiate(enemyPrefab, hit.position, Quaternion.identity);
    //    }
    //}

    //Vector3 GetRandomPointInCameraView()
    //{
    //   // f//loat cameraDistance = 10f; // Distance from the camera
    //    Vector3 randomOffset = Random.onUnitSphere * spawnDistance;

    //    // Adjust the offset to be in front of the camera
    //    randomOffset.z = Mathf.Abs(randomOffset.z);

    //    // Convert camera offset to world space
    //    Vector3 spawnPoint = this.transform.position + randomOffset;

    //    return spawnPoint;
    //}
    public float spherecastradias;
    private void SpawnEnemy1()
    {
        RaycastHit hitdata;
        NavMeshHit navMeshHit;
        Vector3 SpawnPosition = this.transform.forward * spawnDistance + this.transform.position;
        Vector3 randomPoint = SpawnPosition + new Vector3(Random.Range(-3f, 3f), 0, Random.Range(-5,5));
       // Physics.SphereCast(randomPoint + (Vector3.up * 500f), spherecastradias, Vector3.down, out hitdata, 600f);
        // Project the random point onto the navigation mesh
        if (NavMesh.SamplePosition(randomPoint, out navMeshHit, 5, NavMesh.AllAreas))
        {
            Instantiate(enemyPrefab, navMeshHit.position, Quaternion.identity);
        }
        else

        {
            Debug.LogWarning("Cannot spawn enemy outside NavMesh!");
            // If the position is not on the NavMesh, find the nearest point
            //NavMesh.FindClosestEdge(hitdata.point, out navMeshHit, NavMesh.AllAreas);

            //  return navMeshHit.position;
        }

    }

   
}

